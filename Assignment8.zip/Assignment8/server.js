// Import required modules
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

// Initialize Express app
const app = express();
app.use(express.json());

// Connect to MongoDB

(async() =>{
  
  await mongoose.connect('mongodb://127.0.0.1:27017/assignment8', { useNewUrlParser: true });
  console.log("DB Connected");
})();

const userSchema = new mongoose.Schema({
  fullName: String,
  email: String,
  password: String,
});

const User = mongoose.model('User', userSchema);

app.get('/', async (req, res) => {
  

  try {
    // Use an empty query to retrieve all entries
    const queryCondition = {};
    
    // Use find instead of findOne
    const foundUsers = await User.find(queryCondition);

    if (foundUsers.length > 0) {
      // Assuming fullName is a field in your User schema
      const retrievedValues = foundUsers.map(user => user.fullName);
      res.send(`Retrieved values from the database: ${retrievedValues.join(', ')}`);
    } else {
      res.send('No data found in the database');
    }
  } catch (error) {
    console.error('Error retrieving data from the database:', error);
    res.status(500).send('Internal Server Error');
  }


  });
  

app.post('/users/create', async (req, res) => {


  try {
    console.log('Received request body:', req.body);
    const { fullName, email, password } = req.body;
    console.log('Received email:', email);

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).send('Invalid email format');
    }

    if (!fullName || fullName.length < 3) {
      return res.status(400).send('Full name must be at least 3 characters');
    }

    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
    if (!passwordRegex.test(password)) {
      return res.status(400).send('Password must be at least 8 characters and include both letters and numbers');
    }

    // Check if a user with the same fullName already exists
    const existingUser = await User.findOne({ fullName });

    if (existingUser) {
      return res.status(409).send('User with the same fullName already exists');
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      fullName,
      email,
      password: hashedPassword,
    });

    await newUser.save();
    res.status(201).send('User created successfully');
  } catch (error) {
    console.error('Error creating user:', error);
    res.status(500).send('Internal Server Error');
  }


 
});

app.put('/user/edit', async (req, res) => {
   
  const { fullName, password, email } = req.body;

  try {
    // Validate full name
    if (fullName && fullName.length < 3) {
      return res.status(400).send('Full name must be at least 3 characters');
    }

    // Validate password
    if (password) {
      const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
      if (!passwordRegex.test(password)) {
        return res.status(400).send('Password must be at least 8 characters and include both letters and numbers');
      }
    }

    // Find the user by email
    const foundUser = await User.findOne({ email });

    // If user not found, return 404
    if (!foundUser) {
      return res.status(404).send('User not found');
    }

    // Update user details
    if (fullName) foundUser.fullName = fullName;
    if (password) foundUser.password = await bcrypt.hash(password, 10);

    // Save the updated user
    await foundUser.save();

    res.status(200).send('User details updated successfully');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error updating user');
  }




  });
  


app.delete('/user/delete', async (req, res) => {
   
  
  const { email } = req.body;

  try {
    const deletedUser = await User.findOneAndDelete({ email });

    if (!deletedUser) {
      return res.status(404).send('User not found');
    }

    res.status(200).send('User deleted successfully');
  } catch (error) {
    res.status(500).send('Error deleting user');
  }


  });


app.get('/user/getAll', (req, res) => {

  User.find({}, 'fullName email password')
  .then((users) => {
    res.status(200).json(users);
  })
  .catch((err) => {
    res.status(500).send('Error retrieving user data');
  });
});

// Start the server
const PORT = process.env.PORT || 3002;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

